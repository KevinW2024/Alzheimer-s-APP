//
//  TestView.swift
//  Alz_Proto
//
//  Created by Admin on 7/3/23.
//

import SwiftUI

struct SecondView: View {
    @State private var firstName = ""
    @State private var lastName = ""
    @State private var birthday = Date()
    @State private var EC1 = ""
    @State private var EC1Phone = ""
    @State private var EC2 = ""
    @State private var EC2Phone = ""
    @State private var address = ""
    @State private var years = 0
    @State private var bt = ""
    var body: some View {
        VStack {
                    
                    // Add your content for the second view here
            
                    
                    //Spacer()
                }
        Form{
            Section(header:Text("my profile")){
                TextField("First Name", text:$firstName)
                TextField("Last Name", text:$lastName)
                DatePicker("Date of Birth", selection: $birthday,displayedComponents: .date)
                TextField("Home Address ", text:$address)
            }
            Section(header:Text("emergency information")){
                TextField("Emergency Contact #1", text:$EC1)
                TextField("Contact #1 Phone Number", text:$EC1Phone)
                TextField("Emergency Contact #2", text:$EC2)
                TextField("Contact #2 Phone Number", text:$EC2Phone)
            }
            Section(header:Text("my health")){
                TextField("Bloodtype", text:$bt)
                Stepper("Years with Alzheimer's: \(years)", value: $years, in: 0...100)
                
            }
            Section(header:Text("services")){
                Link("User Manual", destination: URL(string:"https://drive.google.com/file/d/1CVT9i1Pd0tPWa2mRc4KX-Q1LbP-wktGg/view?usp=sharing")!)
                Link("Terms of Service", destination: URL(string:"https://drive.google.com/file/d/1n9BRbVmtNZIV1p01_gGvz9rnIHwikQJw/view?usp=sharing")!)
            }
            .navigationTitle("LOL")
        }
        
        
    }
}

struct TestView_Previews: PreviewProvider {
    static var previews: some View {
        TestView()
    }
}
