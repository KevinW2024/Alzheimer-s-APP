//
//  TryView.swift
//  Alz_Proto
//
//  Created by Admin on 7/13/23.
//

import SwiftUI

struct TryView: View {
    var body: some View {
        Text("lol")
            .foregroundStyle(.white)
            .fixedSize(horizontal: false, vertical: true)
            .multilineTextAlignment(.center)
            .padding()
            .frame(width: 300, height: 200)
            .background(Rectangle().fill(Color.orange).shadow(radius: 3))
            .offset(x: 50, y: 100)


    }
}

struct TryView_Previews: PreviewProvider {
    static var previews: some View {
        TryView()
    }
}
