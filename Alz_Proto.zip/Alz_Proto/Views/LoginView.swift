//
//  LoginView.swift
//  Alz_Proto
//
//  Created by Admin on 7/6/23.
//

import SwiftUI

struct LoginView: View {
    @State var email = ""
    @State var password = ""
    var body: some View {
        VStack{
            TextField("Email Adress", text:$email)
                .padding()
                .background(Color(.orange))
            
            SecureField("Password", text:$password)
                .padding()
                .background(Color(.orange))
            
            Button(action:{
                
            }, label: {
                Text("Sign in")
                    .foregroundColor(Color.orange)
                    .frame(width:200,height: 50)
                    .cornerRadius(8)
                    .background(Color.white)
            })
            .padding()
            Spacer()
            
        }
        .navigationTitle("Sign in Page")
    }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView()
    }
}
