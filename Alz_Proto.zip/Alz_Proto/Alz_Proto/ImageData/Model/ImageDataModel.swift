//
//  ImageDataModel.swift
//  Alz_Proto
//
//  Created by Admin on 7/1/23.
//

import Foundation
