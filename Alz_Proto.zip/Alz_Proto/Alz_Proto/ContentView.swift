//
//  ContentView.swift
//  Alz_Proto
//
//  Created by Admin on 7/1/23.
//

import SwiftUI
import UIKit

struct GameView: View{
    var body: some View{
        NavigationView{
            ZStack{
                Color.yellow
            }
            //.navigationTitle("Games")
            
        }
    }
}
struct GalleryView: View{
    @StateObject var imageData = ImageData()
    @State var showImagePicker: Bool = false
    
    var body: some View {
        NavigationView {
            VStack {
                if imageData.imageNote.isEmpty {
                    Text("Try adding an image!")
                        .italic()
                        .foregroundColor(.gray)
                } else {
                    HomeView()
                }
            }
            .navigationTitle("My Memories")
            .sheet(isPresented: $showImagePicker) {
                ImagePicker(sourceType: .photoLibrary) { image in
                    imageData.addNote(image: image,
                                      title: "Edit me!",
                                      desc: "")
                }
            }
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        showImagePicker.toggle()
                    } label: {
                        Label("Image", systemImage: "photo.on.rectangle.angled")
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        withAnimation {
                            imageData.resetUserData()
                        }
                    } label: {
                        Label("Image", systemImage: "trash")
                    }
                    .tint(.red)
                }
            }
        }
        .environmentObject(imageData)
    }
}
struct DietView: View{
    var body: some View{
        NavigationView{
            ZStack{
                Color.green
            }
            //.navigationTitle("Games")
            
        }
    }
}
struct MoodView: View{
    var body: some View{
        NavigationView{
            ZStack{
                Color.yellow
            }
            //.navigationTitle("Games")
            
        }
    }
}

struct TestView: View{
    var body: some View{
        NavigationView{
            VStack{
                
            }
        }
    }
}


struct HomesView: View{
    var body: some View{
        NavigationView{
            
            
            VStack{
                
                Text("New Games")
                    .foregroundStyle(.white)
                    .fixedSize(horizontal: false, vertical: true)
                    .multilineTextAlignment(.center)
                    .padding()
                    .frame(width: 160, height: 150)
                    .background(RoundedRectangle(cornerRadius: 25).fill(Color.orange).shadow(radius: 3))
                    .offset(x: -100, y: 20)
                
                
                Text("My Memories")
                    .foregroundStyle(.white)
                    .fixedSize(horizontal: false, vertical: true)
                    .multilineTextAlignment(.center)
                    .padding()
                    .frame(width: 160, height: 150)
                    .background(RoundedRectangle(cornerRadius: 25).fill(Color.orange).shadow(radius: 3))
                    .offset(x: 100, y: -138)
                
                Text("Leaderboard")
                    .foregroundStyle(.white)
                    .fixedSize(horizontal: false, vertical: true)
                    .multilineTextAlignment(.center)
                    .padding()
                    .frame(width: 160, height: 150)
                    .background(RoundedRectangle(cornerRadius: 25).fill(Color.orange).shadow(radius: 3))
                    .offset(x: -100, y: -128)
                
                Text("Discover More")
                    .foregroundStyle(.white)
                    .fixedSize(horizontal: false, vertical: true)
                    .multilineTextAlignment(.center)
                    .padding()
                    .frame(width: 160, height: 150)
                    .background(RoundedRectangle(cornerRadius: 25).fill(Color.orange).shadow(radius: 3))
                    .offset(x: 100, y: -286)
                
                
                
                
                Form{
                    
                    
                    
                }
                
               
                //.navigationTitle("Home")
                .navigationBarTitle("Hello, User!")
                .navigationBarItems(trailing:
                                        NavigationLink(destination: SecondView()) {
                    Image(systemName: "gear")
                        .imageScale(.large)
                }
                )
                
                .navigationBarItems(trailing:
                                        NavigationLink(destination: APPView()) {
                    Image(systemName: "bubble.right")
                        .imageScale(.large)
                }
                )
                
                
                
                
            }
            
            
            
            
        }
    }
    
}


struct ContentView: View {
    
    var body: some View {
        TabView{
            HomesView()
                .tabItem{
                    Image(systemName: "ipad.homebutton")
                    Text("Home");
                }
            GameView()
            //Text("Games")
                .tabItem{
                    Image(systemName: "gamecontroller")
                    Text("Games");
                }
            GalleryView()
                .tabItem{
                    Image(systemName: "photo")
                    Text("Galleries");
                }
            /*
             DietMedView()
             .tabItem{
             Image(systemName: "checkmark")
             Text("Diet/Med Plans");
             }
             */
            MoodView()
                .tabItem{
                    Image(systemName: "heart")
                    Text("My Mood");
                }
        }
    }
    
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
        }
    }
}
