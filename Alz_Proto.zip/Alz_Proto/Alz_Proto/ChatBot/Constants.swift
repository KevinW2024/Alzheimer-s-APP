//
//  Constants.swift
//  ChatBot
//
//  Created by Admin on 7/7/23.
//

import Foundation
enum Constants{
    static let openAIAPIKey = "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"
    //static let openAIAPIKey = "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"
}
