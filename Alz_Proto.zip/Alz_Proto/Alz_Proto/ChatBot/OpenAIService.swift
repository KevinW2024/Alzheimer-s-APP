//
//  OpenAIService.swift
//  ChatBot
//
//  Created by Admin on 7/7/23.
//

import Foundation
import Alamofire
import Combine
class OpenAIService{
    let baseUrl = "https://api.openai.com/v1/"
    
    func sendMessage(message: String)->AnyPublisher<OpenAICompletionsResponse, Error>{
        let body = OpenAICompletionBody(model:"text-davinci-003", prompt: message, temperature: 0, max_tokens: 512)
        let headers :HTTPHeaders=[
            "Authorization":"Bearer \(Constants.openAIAPIKey)"
        ]
        return Future{
            [weak self] promise in
            guard let self = self else {return}

            AF.request(self.baseUrl+"completions", method: .post,parameters: body, encoder: .json, headers:headers).responseDecodable(of:OpenAICompletionsResponse.self){ response in
                switch response.result{
                case .success(let result):promise(.success(result))
                case .failure(let result):promise(.failure(result))

                }
            }
            
        }
        .eraseToAnyPublisher()
       
        
        
    }
}

struct OpenAICompletionBody: Encodable{
    let model: String
    let prompt: String
    let temperature: Float?
    let max_tokens: Int
}

struct OpenAICompletionsResponse: Decodable{
    let id: String
    let choices: [OpenAICompletionsChoice]
}

struct OpenAICompletionsChoice: Decodable{
    let text: String
}

